import { advanceFuel, activeSafeZone, inventoryCapacity, fuelValue, interactLantern, LOW_FUEL_UNITS, resetDrain, drainingTarget, compareIds } from './fuel.js';
import {insideSafeBoundary,projectSafeBoundary} from './safe-boundary.js';
﻿import { tuning as C, physics, nightDurationTicks } from '../config/game.js';
import { getWorld, worlds, terrainHeight, isSolid, rampTopContact } from '../data/worlds.js';
export const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z), distance3=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const clone=x=>structuredClone(x), clamp=(x,a,b)=>Math.max(a,Math.min(b,x)), idn=x=>Number(String(x).slice(1))||0;
function rng(seed){let x=(seed>>>0)||1;return()=>((x=Math.imul(x,1664525)+1013904223>>>0)/4294967296);}
function motes(w,seed){const r=rng(seed),p=w.motePoints.map((x,i)=>({...x,i}));for(let i=p.length-1;i>0;i--){let j=Math.floor(r()*(i+1));[p[i],p[j]]=[p[j],p[i]];}return p.slice(0,C.firefly_initial).map((x,i)=>({id:`M${i+1}`,x:x.x,y:x.y,z:x.z,kind:'random',available:true,ttl:Infinity,spawnIndex:x.i}));}
function fresh(n,seed){const w=getWorld(n);return{night:n,name:w.name,status:'playing',state:'playing',end_reason:null,terminal_emitted:false,dawn_bonus:0,lastSnapshot:null,tick:0,sim_tick:0,time_ticks:nightDurationTicks(n),score:0,seed,drop_seq:0,paused:false,random_drifters:true,wind_enabled:true,previous:{},player:{x:w.spawn.x,y:w.spawn.y,z:w.spawn.z,vel:{x:0,y:0,z:0},facing:{x:0,z:1},grounded:true,flames:C.initial_flames,light:0,successful_lights:0,get capacity(){return inventoryCapacity(this);},invuln_ticks:0,respawn_ticks:0,dash_ticks:0,dash_cd_ticks:0,pulse_cd_ticks:0,charm_ticks:0,padVelocity:null,dashDirection:null,fallHandled:false},lanterns:w.lamps.map(x=>({...x,fuel_units:0,ever_lit:false,relit_count:0})),motes:motes(w,seed^n),shades:[],drifters:[],charms:w.charms.map(x=>({...x,available:true,respawn_ticks:0})),wind:{active:false,dir_deg:0,warning_ticks:0,active_ticks:0},events:[],eventLog:[],campaign:{id:`C${seed}`,seed,current_night:n,won_scores:{},settings:{volume:1,mouse_sensitivity:1}}};}
export function createGame({seed=1,night=1}={}){const s=fresh(night,seed);const event={type:'night_start',night};s.events.push(event);s.eventLog.push(event);return s;}
// Isolated benchmark profile: ordinary campaign behavior is unchanged.
export function createBenchmarkGame({seed=42}={}){
 const s=createGame({night:1,seed}),w=getWorld(1),rand=rng(seed);
 s.benchmarkMode=true;s.random_drifters=false;s.wind_enabled=false;
 Object.assign(s.player,{x:0,y:0,z:0,vel:{x:0,y:0,z:0},motionVelocity:{x:0,z:0},facing:{x:0,z:1}});
 s.lanterns.forEach(l=>{if(['L1','L2','L3'].includes(l.id)){l.lit=true;l.fuel_units=6000;l.ever_lit=true;}});
 s.motes=Array.from({length:100},(_,i)=>{const a=rand()*Math.PI*2,r=Math.sqrt(rand())*38,p=w.surfaces[0];return{id:`BM${i+1}`,x:Math.cos(a)*r,y:p.y,z:Math.sin(a)*r,kind:'random',available:true,ttl:Infinity,spawnIndex:i};});
 const shadeOffset=rand()*Math.PI*2,goldenAngle=Math.PI*(3-Math.sqrt(5));
 s.shades=Array.from({length:200},(_,i)=>{const a=shadeOffset+i*goldenAngle,r=38*Math.sqrt((i+.5)/200);return{id:`BS${i+1}`,x:Math.cos(a)*r,y:0,z:Math.sin(a)*r,state:'wander',state_ticks_left:0,target_lantern_id:null,drain_target_lantern_id:null,wander_deg:rand()*360,eviction_ticks:0,drain_ticks:0,random:rand};});
 return s;
}
export const createCampaign=createGame;
const emit=(s,type,data={})=>{const event={type,...data};s.events.push(event);s.eventLog.push(event);};
function walk(e,x,z,speed){let dx=x-e.x,dz=z-e.z,d=Math.hypot(dx,dz);if(d){const m=Math.min(speed/C.tick_rate,d)/d;e.x+=dx*m;e.z+=dz*m;}}
function drop(s,n,p){for(let i=0;i<n;i++){let a=(s.sim_tick+i*C.drop_angle_step)*Math.PI/180,r=C.hit_drop_min_radius+((s.sim_tick+i*C.drop_radius_step)%C.drop_radius_modulus)/C.drop_radius_modulus,x=p.x+Math.cos(a)*r,z=p.z+Math.sin(a)*r,y=terrainHeight(s.night,x,z,p.y);if(y!==null)s.motes.push({id:`MD${s.drop_seq++}`,x,y,z,kind:'dropped',available:true,ttl:C.hit_drop_ttl});}}
function dropAt(s,n,p){const y=terrainHeight(s.night,p.x,p.z,p.y);if(y===null)return;for(let i=0;i<n;i++)s.motes.push({id:`MD${s.drop_seq++}`,x:p.x,y,z:p.z,kind:'dropped',available:true,ttl:C.hit_drop_ttl});}
function fall(s){const p=s.player;if(p.y>=C.fall_y||p.fallHandled)return;p.fallHandled=true;p.flames=Math.max(0,p.flames-1);let lost=p.light;p.light=0;emit(s,'player_hit',{source:'fall',lost});if(!p.flames){s.status='lost';s.end_reason='no_flames';}else{p.respawn_ticks=C.fall_wait_ticks;p.vel={x:0,y:0,z:0};p.padVelocity=null;p.invuln_ticks=0;}}
function hit(s,e){const p=s.player;if(p.invuln_ticks||p.respawn_ticks||e.eviction_ticks||['stunned','recoil','spawning'].includes(e.state))return false;p.flames=Math.max(0,p.flames-1);const lost=Math.floor(p.light/C.light_drop_divisor);p.light-=lost;drop(s,lost,p);p.invuln_ticks=C.hit_invuln;resetDrain(e);e.state='recoil';e.state_ticks_left=C.shade_recoil_ticks;e.recoil_dir={x:e.x-p.x,z:e.z-p.z};if(!Math.hypot(e.recoil_dir.x,e.recoil_dir.z))e.recoil_dir={x:1,z:0};emit(s,'player_hit',{source:e.id,lost});return true;}
function moveHorizontal(s,p,dx,dz){const count=Math.max(1,Math.ceil(Math.hypot(dx,dz)/physics.collisionStep));for(let i=0;i<count;i++){const x=p.x+dx/count,z=p.z+dz/count;if(isSolid(s.night,x,p.y,z))break;p.x=x;p.z=z;}}
function playerMove(s,a){const p=s.player;if(p.respawn_ticks)return;const x0=p.x,y0=p.y,z0=p.z;const mx=+a.moveX||0,mz=+a.moveZ||0,mag=Math.hypot(mx,mz),ux=mag?mx/Math.max(1,mag):0,uz=mag?mz/Math.max(1,mag):0;if(mag)p.facing={x:mx/mag,z:mz/mag};let h=terrainHeight(s.night,p.x,p.z,p.y);p.grounded=h!==null&&p.y>=h-1e-8&&p.y<=h+C.ground_epsilon&&p.vel.y<=0;if(p.grounded){p.y=h;p.vel.y=0;const pad=worlds[s.night].pads.find(q=>distance(p,q)<=q.r);if(pad){const d=Math.hypot(pad.target.x-p.x,pad.target.z-p.z)||1;p.padVelocity=s.night===3?{x:0,z:-pad.speed}:{x:(pad.target.x-p.x)/d*pad.speed,z:(pad.target.z-p.z)/d*pad.speed};p.vel.y=pad.vy;p.grounded=false;}}if(a.jump&&!s.previous.jump&&p.grounded){p.vel.y=C.jump_speed;p.grounded=false;emit(s,'jump');}
 const edge=!!a.dash&&!s.previous.dash;if(edge&&!p.dash_ticks&&(!p.dash_cd_ticks||p.charm_ticks)){p.dashDirection=clone(p.facing);p.dash_ticks=Math.round(C.dash_duration_s*C.tick_rate);p.dash_cd_ticks=p.charm_ticks?0:Math.round(C.dash_cooldown_s*C.tick_rate);emit(s,'dash');}
 const followsGround=p.grounded;
 if(p.dash_ticks){moveHorizontal(s,p,p.dashDirection.x*C.dash_speed/C.tick_rate,p.dashDirection.z*C.dash_speed/C.tick_rate);p.dash_ticks--;}
 else if(p.padVelocity){moveHorizontal(s,p,p.padVelocity.x/C.tick_rate,p.padVelocity.z/C.tick_rate);p.vel.y+=C.gravity/C.tick_rate;p.y+=p.vel.y/C.tick_rate;}
 else{let speed=p.charm_ticks?C.charm_run_speed:C.run_speed,d=speed/C.acceleration_ticks;// Controlled velocity excludes dash, pad launch and additive wind.
 const control=p.motionVelocity??{x:0,z:0};p.vel.x=control.x;p.vel.z=control.z;p.vel.x+=clamp(ux*speed-p.vel.x,-d,d);p.vel.z+=clamp(uz*speed-p.vel.z,-d,d);p.motionVelocity={x:p.vel.x,z:p.vel.z};let nx=p.x+p.vel.x/C.tick_rate,nz=p.z+p.vel.z/C.tick_rate;if(!isSolid(s.night,nx,p.y,nz)){p.x=nx;p.z=nz;}if(!p.grounded){p.vel.y+=C.gravity/C.tick_rate;p.y+=p.vel.y/C.tick_rate;}}
 // Snapshot velocity below includes all displacement; never feed it back into control.
 if(s.wind.active){let w=s.wind.dir_deg*Math.PI/180;const wx=p.x+Math.cos(w)*C.gust_speed/C.tick_rate,wz=p.z+Math.sin(w)*C.gust_speed/C.tick_rate;if(!isSolid(s.night,wx,p.y,wz)){p.x=wx;p.z=wz;}}
 // Land only across a support from above; grounded ramp-following is bounded separately.
 h=terrainHeight(s.night,p.x,p.z,y0);if(followsGround){const lip=rampTopContact(s.night,{x:x0,y:y0,z:z0},p);if(lip!==null)h=lip;}const follow=followsGround&&h!==null&&Math.abs(h-y0)<=physics.supportTolerance;
 p.grounded=false;if(h!==null&&p.vel.y<=0&&(y0>=h-1e-8||follow)&&(p.y<=h+1e-8||follow)){p.y=h;p.vel.y=0;p.padVelocity=null;p.grounded=true;}
 if(p.grounded){let pad=worlds[s.night].pads.find(q=>distance(p,q)<=q.r);if(pad){let d=Math.hypot(pad.target.x-p.x,pad.target.z-p.z)||1;p.padVelocity=s.night===3?{x:0,z:-pad.speed}:{x:(pad.target.x-p.x)/d*pad.speed,z:(pad.target.z-p.z)/d*pad.speed};p.vel.y=pad.vy;p.grounded=false;}}p.vel.x=(p.x-x0)*C.tick_rate;p.vel.z=(p.z-z0)*C.tick_rate;fall(s);}
function pickups(s){let p=s.player;if(p.respawn_ticks)return;for(const m of s.motes){let h=terrainHeight(s.night,m.x,m.z,m.y)??m.y;if(m.available&&p.light<inventoryCapacity(p)&&distance(p,m)<=C.firefly_pickup_xz&&Math.abs(p.y-h)<=C.firefly_pickup_height){m.available=false;p.light++;emit(s,'mote_picked',{mote_id:m.id});}}for(const q of s.charms){let h=terrainHeight(s.night,q.x,q.z,q.y)??q.y;if(q.available&&distance(p,q)<=C.firefly_pickup_xz&&Math.abs(p.y-h)<=C.firefly_pickup_height){q.available=false;q.respawn_ticks=C.charm_respawn_ticks;p.charm_ticks=C.charm_duration_ticks;emit(s,'charm_picked',{charm_id:q.id,charm_ticks:C.charm_duration_ticks});}}}
function lamp(s,a){if(a.interact)interactLantern(s,emit);}
function safe(s){
 if(!s.lanterns.some(activeSafeZone))return;
 for(const e of s.shades){
  const l=s.lanterns.filter(x=>activeSafeZone(x)&&distance(x,e)<=C.lantern_safe_radius)
   .sort((a,b)=>distance(a,e)-distance(b,e)||compareIds(a,b))[0];
  if(l){if(insideSafeBoundary(l,e)){
   projectSafeBoundary(l,e);
   e.eviction_ticks=C.safe_evict_ticks;
  }}
 }
}
function pulse(s,a){let p=s.player;if(!a.pulse||s.previous.pulse||p.respawn_ticks||p.light<C.pulse_cost||p.pulse_cd_ticks)return;p.light-=C.pulse_cost;p.pulse_cd_ticks=C.pulse_cooldown_s*C.tick_rate;let c={x:p.x,y:p.y+C.pulse_center_y,z:p.z};for(const e of s.shades)if(distance3(c,{x:e.x,y:e.y+C.shade_center_y,z:e.z})<=C.pulse_radius){s.score+=e.state==='drain'?C.drain_pulse_score:C.pulse_score;resetDrain(e);e.state='stunned';e.state_ticks_left=C.stun_ticks;e.push_ticks=C.push_ticks;let dx=e.x-p.x,dz=e.z-p.z,d=Math.hypot(dx,dz);e.push_dir=d?{x:dx/d,z:dz/d}:{x:1,z:0};}for(const d of s.drifters)if(distance3(c,{x:d.x,y:d.y+C.shade_center_y,z:d.z})<=C.pulse_radius){if(d.state==='chase'){d.state='flee';d.state_ticks_left=C.drifter_flee_ticks;d.stolen=0;d.flee_dir={x:d.x-p.x,z:d.z-p.z};}else if(d.state==='flee'&&d.stolen){dropAt(s,d.stolen,d);emit(s,'drifter_drop',{drifter_id:d.id,amount:d.stolen});d.stolen=0;d.state_ticks_left=C.drifter_drop_ticks;}}emit(s,'pulse');}
function ai(s){
 for(const e of s.shades.slice().sort(compareIds)){
  if(e.state==='spawning'){e.state='wander';continue;}
  // Pulse state wins; a reactivated safe zone still blocks movement and damage.
  if(e.state==='stunned'){
   resetDrain(e);
   if(e.eviction_ticks>0)e.eviction_ticks--;
   else if(e.push_ticks>0){
    const x=e.x+e.push_dir.x*C.push_distance/C.push_ticks,z=e.z+e.push_dir.z*C.push_distance/C.push_ticks;
    if(!isSolid(s.night,x,e.y,z)){e.x=x;e.z=z;}
   }
   if(e.push_ticks>0)e.push_ticks--;
   if(!e.state_ticks_left)e.state='wander';
   continue;
  }
  if(e.state==='drain'){
   if(!drainingTarget(s,e)){
    e.state='wander';resetDrain(e);e.target_lantern_id=null;
    if(e.eviction_ticks>0)e.eviction_ticks--;
    continue;
   }
   if(distance(e,s.player)<=C.lantern_safe_radius){
    e.state='chase';resetDrain(e);e.target_lantern_id=null;
   }else continue;
  }
  if(e.eviction_ticks>0){e.eviction_ticks--;continue;}
  if(e.state==='recoil'){
   const d=Math.hypot(e.recoil_dir.x,e.recoil_dir.z)||1,
    x=e.x+e.recoil_dir.x/d*C.shade_recoil_distance/C.shade_recoil_ticks,
    z=e.z+e.recoil_dir.z/d*C.shade_recoil_distance/C.shade_recoil_ticks;
   if(!isSolid(s.night,x,e.y,z)){e.x=x;e.z=z;}
   if(!e.state_ticks_left)e.state='wander';
   continue;
  }
  const d=distance(e,s.player),before={x:e.x,z:e.z};
  let changed=false;
  if(!s.benchmarkMode&&e.state==='wander'&&d<=C.shade_detect){e.state='chase';e.target_lantern_id=null;changed=true;}
  if(e.state==='chase'&&d>C.shade_abandon){e.state='wander';e.target_lantern_id=null;changed=true;}
  if(e.state==='chase')walk(e,s.player.x,s.player.z,s.night===3?C.night3_shade_speed:C.shade_speed);
  else if(e.state==='wander'){
   let target=null,best=Infinity;
   for(const l of s.lanterns)if(l.lit&&l.fuel_units<LOW_FUEL_UNITS){const d=distance(l,e);if(d<best||d===best&&compareIds(l,target)<0){target=l;best=d;}}
   if(!target){for(const l of s.lanterns)if(!l.lit){const d=distance(l,e);if(d<best||d===best&&compareIds(l,target)<0){target=l;best=d;}}}
   e.target_lantern_id=target?.id??null;
   if(!changed&&target?.lit&&target.fuel_units<LOW_FUEL_UNITS&&distance(target,e)<=C.lantern_radius){e.state='drain';resetDrain(e);e.drain_target_lantern_id=target.id;continue;}
   if(target)walk(e,target.x,target.z,C.shade_wander_speed);
   else walk(e,e.x+Math.cos(e.wander_deg*Math.PI/180),e.z+Math.sin(e.wander_deg*Math.PI/180),C.shade_wander_speed);
   if(isSolid(s.night,e.x,e.y,e.z)){e.x=before.x;e.z=before.z;}
   if(!changed&&target?.lit&&target.fuel_units<LOW_FUEL_UNITS&&distance(target,e)<=C.lantern_radius){
    e.state='drain';resetDrain(e);e.drain_target_lantern_id=target.id;
   }
  }
  if(isSolid(s.night,e.x,e.y,e.z)){e.x=before.x;e.z=before.z;}
  for(const l of s.lanterns.filter(activeSafeZone)){
   if(insideSafeBoundary(l,e)){
    projectSafeBoundary(l,e);
   }
  }
  const h=terrainHeight(s.night,e.x,e.z,e.y);if(h!==null)e.y=h;
 }
}
function drift(s){for(const d of s.drifters){if(d.state==='removed')continue;if(d.state==='flee'&&!d.state_ticks_left){d.state='removed';continue;}let n=distance(d,s.player);if(d.state==='idle'){if(s.player.light>=C.drifter_chase_min_light&&n<=C.drifter_chase_distance)d.state='chase';else walk(d,d.x+Math.cos(d.wander_deg*Math.PI/180),d.z+Math.sin(d.wander_deg*Math.PI/180),C.drifter_idle_speed);}if(d.state==='chase'&&(s.player.light<C.drifter_chase_min_light||n>C.drifter_chase_distance))d.state='idle';if(d.state==='chase')walk(d,s.player.x,s.player.z,C.drifter_speed);if(d.state==='flee'){let v=d.flee_dir??{x:1,z:0},m=Math.hypot(v.x,v.z);if(!m){v={x:1,z:0};m=1;}d.x+=v.x/m*C.drifter_speed/C.tick_rate;d.z+=v.z/m*C.drifter_speed/C.tick_rate;}}}
function contacts(s){let p=s.player;if(p.respawn_ticks)return;for(const d of s.drifters.filter(x=>x.state==='chase').sort((a,b)=>idn(a.id)-idn(b.id))){if(d.stolen||distance(d,p)>C.drifter_contact_xz)continue;let n=Math.min(C.drifter_theft,p.light);p.light-=n;d.stolen=n;d.state='flee';d.state_ticks_left=C.drifter_flee_ticks;d.flee_dir={x:d.x-p.x,z:d.z-p.z};if(!Math.hypot(d.flee_dir.x,d.flee_dir.z))d.flee_dir={x:1,z:0};emit(s,'drifter_steal',{drifter_id:d.id,amount:n,carried:p.light});}if(s.lanterns.some(l=>activeSafeZone(l)&&distance(l,p)<=C.lantern_safe_radius))return;for(const e of s.shades.slice().sort((a,b)=>idn(a.id)-idn(b.id)))if(Math.abs(e.y-p.y)<=C.shade_contact_height&&distance(e,p)<=C.shade_contact_xz&&hit(s,e))break;}
function spawn(s){let w=worlds[s.night],rand=rng(s.seed^Math.imul(s.sim_tick,2654435761)),count=s.motes.filter(x=>x.kind==='random'&&x.available).length;if(s.sim_tick&&s.sim_tick%C.firefly_spawn_ticks===0&&count<C.firefly_cap){let used=new Set(s.motes.filter(x=>x.kind==='random'&&x.available).map(x=>x.spawnIndex)),i=w.motePoints.findIndex((_,j)=>!used.has(j));if(i>=0){let p=w.motePoints[i];s.motes.push({id:`M${s.sim_tick}`,x:p.x,y:p.y,z:p.z,kind:'random',available:true,ttl:Infinity,spawnIndex:i});}}
 let interval=[0,C.shade_spawn_interval_night1,C.shade_spawn_interval_night2,C.shade_spawn_interval_night3][s.night],max=[0,C.shade_spawn_cap_night1,C.shade_spawn_cap_night2,C.shade_spawn_cap_night3][s.night];if((s.sim_tick===C.shade_spawn_first||s.sim_tick>C.shade_spawn_first&&(s.sim_tick-C.shade_spawn_first)%interval===0)&&s.shades.length<max)for(let j=0;j<(s.sim_tick===C.shade_spawn_first?2:1)&&s.shades.length<max;j++){let opts=w.shadePoints.filter(x=>distance(x,s.player)>=C.shade_spawn_valid_min_distance&&!s.shades.some(e=>distance(e,x)<1));if(!opts.length)break;let p=opts[Math.floor(rand()*opts.length)],id=`S${s.shades.length+1}`;s.shades.push({id,x:p.x,y:p.y,z:p.z,state:'spawning',state_ticks_left:0,random:rand,wander_deg:rand()*360,eviction_ticks:0});emit(s,'shade_spawn',{shade_id:id});}
 if(s.random_drifters&&s.night>1&&s.sim_tick&&s.sim_tick%C.drifter_spawn_ticks===0&&s.drifters.filter(x=>x.state!=='removed').length<C.drifter_cap){let opts=w.shadePoints.filter(x=>distance(x,s.player)>=C.shade_spawn_valid_min_distance);if(opts.length){let p=opts[Math.floor(rand()*opts.length)],id=`D${s.drifters.length+1}`;s.drifters.push({id,x:p.x,y:p.y,z:p.z,state:'idle',stolen:0,state_ticks_left:0,wander_deg:rand()*360});emit(s,'drifter_spawn',{drifter_id:id});}}
 if(s.wind_enabled&&s.night===3){let m=s.sim_tick%C.gust_interval_ticks;if(m===C.gust_interval_ticks-C.gust_warning_ticks){s.wind.dir_deg=rand()*360;s.wind.warning_ticks=C.gust_warning_ticks;emit(s,'wind_warning',{dir_deg:s.wind.dir_deg});}if(m===0){s.wind.active=true;s.wind.active_ticks=C.gust_duration_ticks;emit(s,'wind_start',{dir_deg:s.wind.dir_deg});}if(s.wind.active&&!s.wind.active_ticks)s.wind.active=false;}}
function timers(s){s.sim_tick++;s.time_ticks=Math.max(0,s.time_ticks-1);let p=s.player;for(let k of ['invuln_ticks','respawn_ticks','dash_cd_ticks','pulse_cd_ticks','charm_ticks'])p[k]=Math.max(0,p[k]-1);for(let x of [...s.shades,...s.drifters])x.state_ticks_left=Math.max(0,x.state_ticks_left-1);for(let m of s.motes)if(m.kind==='dropped'&&m.available&&--m.ttl<=0)m.available=false;if(s.wind.warning_ticks)s.wind.warning_ticks--;if(s.wind.active_ticks)s.wind.active_ticks--;for(let q of s.charms)if(!q.available&&--q.respawn_ticks<=0)q.available=true;if(p.respawn_ticks===0&&p.fallHandled&&p.flames>0){const w=getWorld(s.night);Object.assign(p,{x:w.spawn.x,y:w.spawn.y,z:w.spawn.z,vel:{x:0,y:0,z:0},grounded:true,invuln_ticks:C.hit_invuln,fallHandled:false,motionVelocity:{x:0,z:0}});}}
function end(s){
 if(!s.player.flames){s.status='lost';s.end_reason='no_flames';s.campaign.menu_state='retry';}
 else if(!s.time_ticks){
  const lit=s.lanterns.filter(l=>l.lit);
  if(lit.length>=Math.ceil(C.win_ratio*s.lanterns.length)){
   s.status='won';s.end_reason='dawn_survived';
   s.dawn_bonus=lit.reduce((sum,l)=>sum+C.dawn_lantern_bonus+Math.floor(l.fuel_units/C.tick_rate),0)+C.win_flame_bonus*s.player.flames;
   s.score+=s.dawn_bonus;
   s.campaign.won_scores[s.night]=s.score;s.campaign.menu_state=s.night===3?'dawn':'results';
  }else{s.status='lost';s.end_reason='dawn';s.campaign.menu_state='retry';}
 }
 if(s.status!=='playing'&&!s.terminal_emitted){emit(s,'game_over',{reason:s.end_reason});s.terminal_emitted=true;}
}
export function restartNight(s){let camp=s.campaign;Object.assign(s,fresh(s.night,camp.seed));s.campaign=camp;const event={type:'night_start',night:s.night};s.events.push(event);s.eventLog.push(event);return s;}
export function startNight(s,n){if(![1,2,3].includes(n))throw new RangeError('night must be 1, 2, or 3');let camp=s.campaign;Object.assign(s,fresh(n,camp.seed));s.campaign=camp;s.campaign.current_night=n;const event={type:'night_start',night:n};s.events.push(event);s.eventLog.push(event);return s;}
export function step(s,a={}){a={...a,pulse:a.pulse??a.glow};s.tick++;s.events=[];let edge=!!a.pause&&!s.previous.pause;s.previous.pause=!!a.pause;if(s.status!=='playing'){if(a.restart)restartNight(s);return s;}if(edge){s.paused=!s.paused;emit(s,s.paused?'paused':'resumed');if(s.paused){s.state='paused';s.previous={dash:!!a.dash,pause:!!a.pause,jump:!!a.jump,interact:!!a.interact,pulse:!!a.pulse};if(s.tick%60===0&&s.cachePeriodicSnapshots!==false)s.lastSnapshot=gameSnapshot(s);return s;}}if(s.paused){s.state='paused';s.previous={dash:!!a.dash,pause:!!a.pause,jump:!!a.jump,interact:!!a.interact,pulse:!!a.pulse};if(s.tick%60===0&&s.cachePeriodicSnapshots!==false)s.lastSnapshot=gameSnapshot(s);return s;}s.state='playing';timers(s);advanceFuel(s,emit);playerMove(s,a);if(s.player.flames){pickups(s);lamp(s,a);}safe(s);if(s.player.flames)pulse(s,a);ai(s);drift(s);if(s.player.flames)contacts(s);spawn(s);end(s);s.previous={dash:!!a.dash,pause:!!a.pause,jump:!!a.jump,interact:!!a.interact,pulse:!!a.pulse};if(s.tick%60===0&&s.cachePeriodicSnapshots!==false)s.lastSnapshot=gameSnapshot(s);return s;}
export function stepBenchmarkWander(s){if(!s?.benchmarkMode)throw new TypeError('benchmark game required');s.tick++;s.sim_tick++;s.events=[];safe(s);ai(s);if(s.shades.some(e=>e.state!=='wander'))throw new Error('benchmark Shade left wander state');return s;}
export function gameSnapshot(s,{history=true}={}){let sec=n=>Math.round(n/C.tick_rate*1000)/1000;return{tick:s.tick,sim_tick:s.sim_tick,night:s.night,state:s.paused?'paused':s.status,time_s:sec(s.time_ticks),score:s.score,end_reason:s.end_reason??null,wind:{active:s.wind.active,dir_deg:s.wind.dir_deg},player:{x:s.player.x,y:s.player.y,z:s.player.z,vel:{...s.player.vel},grounded:s.player.grounded,flames:s.player.flames,light:s.player.light,capacity:inventoryCapacity(s.player),invuln:s.player.invuln_ticks>0,dash_cd_s:sec(s.player.dash_cd_ticks),pulse_cd_s:sec(s.player.pulse_cd_ticks),charm_s:sec(s.player.charm_ticks)},lanterns:s.lanterns.map(x=>({id:x.id,pos:{x:x.x,y:x.y,z:x.z},lit:x.lit,progress:x.progress,fuel:fuelValue(x),ever_lit:x.ever_lit,relit_count:x.relit_count})),shades:s.shades.slice().sort(compareIds).map(x=>({id:x.id,pos:{x:x.x,y:x.y,z:x.z},state:x.state,state_ticks_left:x.state_ticks_left})),motes:s.motes.filter(x=>x.available).map(x=>({id:x.id,pos:{x:x.x,y:x.y,z:x.z},kind:x.kind,ttl_s:x.kind==='dropped'?sec(x.ttl):null})),drifters:s.drifters.map(x=>({id:x.id,pos:{x:x.x,y:x.y,z:x.z},state:x.state,stolen:x.stolen})),charms:s.charms.map(x=>({id:x.id,available:x.available,respawn_s:sec(x.respawn_ticks)})),events:clone(history?s.eventLog:s.events),campaign_score:Object.values(s.campaign.won_scores).reduce((a,b)=>a+b,0)};}
